module.exports = {
    greet: function(){
        console.log("we are now using a module!");
    },
    add: function(num1, num2){
        console.log("the sum is:", num1 + num2);
    },
    mult: function (num1, num2){
        console.log("the total is:", num1 * num2);
    },
    divi: function (num1, num2){
        console.log("the total is:", num1 / num2);
    }
}
