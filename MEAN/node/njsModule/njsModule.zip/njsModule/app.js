var myModule = require('./myModule');
myModule.greet();
myModule.add(5,6);
myModule.mult(5,6);
myModule.divi(20,5);

var randModule = require('./randModule');
randModule.greet();
randModule.add(5,6);
randModule.mult(5,6);
randModule.divi(20,5);
randModule.square(4);
randModule.randNum(50);
