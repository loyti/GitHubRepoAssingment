from django.shortcuts import render, redirect, HttpResponse
from .models import User, Quote
from django.contrib import messages
import bcrypt

# Create your views here.

def index(request):
    session = request.session
    return render(request, 'main/index.html')

def login(request):
    if 'user_id' in request.session:
        return redirect('/dashboard')
    return render(request, 'main/quotes.html')

def register(request):
    if 'user_id' in request.session:
        return redirect('/')
    return render(request, 'main/quotes.html')

def quotes(request):
    users = User.objects.all()
    current_user = User.objects.get(id=request.session['user_id'])
    user = User.objects.get(id=request.session['user_id'])

    if 'user_id' not in request.session:
        messages.error(request, 'You are not logged in.')
        return redirect('/')

    quotes = user.quotes_wall.all().order_by('-created_at')

    context = {
        'current_user_id' : request.session['user_id'],
        'user' : user,
        'quotes': quotes,
    }

    return render(request, 'main/quotes.html', context)

def user(request, user_id):
    if 'user_id' not in request.session:
        messages.error(request, 'You are not logged in.')
        return redirect('/')

    owner = User.objects.get(id=user_id)

    quotes = owner.quotes_wall.all().order_by('-created_at')

    context = {
        'current_user_id' : request.session['user_id'],
        'user' : user,
        'quotes': quotes,
    }
    return render(request, 'main/user.html', context)

def logout(request):
    request.session.clear()
    return redirect('/')

def signin(request):
    if request.method == 'POST':
        try:
            get_email = User.objects.get(email = request.POST['email'])
            if bcrypt.checkpw(request.POST['password'].encode(), get_email.password.encode()):
                request.session['user_id'] = get_email.id

                current_user = User.objects.get(id=request.session['user_id'])

                return redirect('/quotes')

        except:
            messages.error(request, 'Your information is incorrect. Please try again.')
    return redirect('/signin')

def create_user(request):
    if request.method == 'POST':

        # validate our form data
        errors = User.objects.user_validator(request.POST)

        # populate messages with errors if true
        if len(errors):
            for error in errors:
                messages.error(request, error)
            return redirect('/')
        else:
        # if no errors
            try:
                # check email if it already exists in the database.
                check_email = User.objects.get(email = request.POST['email'])
                messages.error(request, 'This email already exists.')
                return redirect('/')
            except:
                # hash password
                hash_it = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt())

                # if first user in data base assign admin user level
                check_users = User.objects.all()

                # insert user into database
                user = User(user_name=request.POST['user_name'], alias=request.POST['alias'],email=request.POST['email'],password=hash_it)
                user.save()
                messages.success(request, 'You have successfully registered')
    return redirect('/')

def new_quote(request):
    if request.method == 'POST':
        errors = User.objects.user_validator(request.POST)

        # populate messages with errors if true
        if len(errors):
            for error in errors:
                messages.error(request, error)
            return redirect('/quotes')

        userCount = User.objects.get(quoteCount=request.POST['quoteCount'])
        quote = Quote(author=request.POST['author'],content=request.POST['content'],user=user)
        user = User(quoteCount=(userCount + request.POST['quoteCount']))
        user.save()
        quote.save()
        messages.success(request,'Successfully posted your quote.')
    return redirect('/quotes')
